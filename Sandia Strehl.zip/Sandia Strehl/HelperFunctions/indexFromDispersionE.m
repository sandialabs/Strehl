function nDesired = indexFromDispersionE(desiredWavelength,ne,Ve)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION nDesired = indexFromDispersionE(desiredWavelength,ne,Ve)
%
% PURPOSE:
%	indexFromDispersionE takes the index of refraction and reciprocal
%	dispersion at a reference wavelength, calculating the approximate index
%	of refraction at the desired wavelength. The calculation assumes that
%	the dispersion is linear over the regime used for the Abbe number
%	(reciprocal dispersion) calculation. indexFromDispersionE is
%	specifically designed for the Abbe number for the mercury e-line at
%	546.07 nm. 
%
% DEPENDENCIES:
%	-None-
%
% INPUTS:
%   desiredWavelength:
%       The wavelength for which to calculate the index of refraction
%	ne:
%		The index of refraction at the mercury e-line (546.07 nm). 
%	Ve:
%		The Abbe number for the mercury d-line at 546.07 nm. 
%
% OUTPUTS:
%   nDesired:
%       The index of refraction at the specified input wavelength. 
%
% REFERENCES:
%	Schott TIE-29: Refractive Index and Dispersion
%
% PROGRAMMER COMMENTS:
%	-None-
%
% LIMITATIONS:
%	1) The calculation is specific to the Abbe number at the mercury 
%		e-line.
%	2) The calculation assumes that the dispersion is linear over the
%		regime used in the calculation of Ve. Further, it assumes the
%		dispersion is linear between the mercury e-line and the specified
%		wavelength. As such, the output will be an approximation, whose
%		accuracy depends on the validity of these assumptions. 
%	3) No provision was made for complex indices of refraction or for
%		absorption. 


chromaticDispersion = (ne-1)/Ve/(479.99-643.85);
nDesired = ne + chromaticDispersion*(desiredWavelength - 546.07);