function results = scanIndex(refractiveIndexRange)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION results = scanIndex(refractiveIndexRange)
%
% PURPOSE:
%	scanIndex.m is designed to determine for a given coverslip index of
%	refraction the combinations of immersion oil thickness and coverslip
%	thickness that maximize the Strehl ratio and ensquared energy. It also
%	determines the immersion oil thickness that optimizes the Strehl ratio
%	for a coverslip with the specified index of refraction but a design
%	thickness. While the process is automated, it can be very slow,
%	potentially taking many hours. This code is not expected to be used
%	routinely, but was useful for generating a figure. 
%
% DEPENDENCIES:
%	specifyStrehlDefaults.m
%	gibsonLanni.m
%	roundSigFigure.m
%	fastBinND.m
%	fastCounter.m
%
% INPUTS:
%	refractiveIndexRange:
%		A vector specifying all the coverslip refractive indices to
%		calculate results for. 
%
% OUTPUTS: 
%	results:
%		A cell array, where each element of the cell array corresponds to a
%		value in refractiveIndexRange. The cell may have up to three
%		entries - 1) the optimum Strehl ratio pair, 2) the optimum
%		ensquared energy pair, 3) the optimum immersion oil thickness for
%		the design coverslip, not necessarily in that order. The fields
%		are:
%			strehlRatio:
%				The Strehl ratio for the corresponding parameters. 
%			ensquaredEnergy:
%				The ensquared energy for the corresponding parameters. 
%			detectorPSF:
%				The PSF for the corresponding parameters with pixels size
%				as specified for the detector. Usually shrunk down to a
%				small field of view for computational efficiency. 
%			highResolutionPSF:
%				The PSF for the corresponding parameters calculated at a
%				higher resolution than the detector. Experience has shown
%				it is necessary to calculate at a higher resolution and
%				integrate; calculating at only one discrete point per pixel
%				can give inaccurate results. 
%			isAccurate:
%				A Boolean value. If false, the results are likely
%				inaccurate; the code should be run with a higher accuracy
%				setting (finer resolution for rho). 
%			wavelength:
%				The wavelength of light for which the PSF was simulated in
%				nm. 
%			numericalAperture:
%				The numerical aperture of the microscope objective. Note,
%				the effective NA may be smaller if a layer has a lower
%				refractive index. 
%			magnification:
%				The magnification of the microscope (objective plus any
%				additional magnification). 
%			pixelSize:
%				The pixel size of the detector in microns. 
%			computationalTime:
%				The time in seconds required to calculate the whole range. 
%			rhoInterval:
%				Rho is divided into steps 0:1/rhoInterval:1. More steps
%				takes longer, but too few steps may be inaccruate. 
%			refractiveIndices:
%				A sub structure with the refractive indices, both design
%				and actual, for the various layers. 
%			layerThicknesses:
%				A sub structure with the layer thicknesses, both design
%				and actual, for the various layers. Note that no actual
%				layer thickness is given for the immersion layer; instead
%				the optimum immersion layer thickness is given. The optimum
%				immersion layer thickness is the immersion layer thickness
%				that maximizes the Strehl ratio for the other specified
%				parameters. 
%
% REFERENCES:
%	1) Gibson, S. F. and F. Lanni (1991). "Experimental Test of an 
%		Analytical Model of Aberration in an Oil-Immersion Objective Lens 
%		Used in 3-Dimensional Light-Microscopy." Journal of the Optical 
%		Society of America a-Optics Image Science and Vision 8(10): 
%		1601-1613.
%	2) Born, M. and E. Wolf (1999). Principles of Optics. New York, 
%		Cambridge University Press.
%
% PROGRAMMER COMMENTS:
%	In this code, the design values are specified by the normal labels
%	(e.g. Ns) and the actual values are specified by prime (e.g. NsPrime).
%	In reference, the convention is often to have the design values
%	specified by a star (e.g. Ns* or n_s^* in Latex) and the actual values
%	specified with no modified (e.g. Ns or n_s in Latex)
%
% LIMITATIONS:
%	1) The code uses discrete approximations to calculate the integrals. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the parameters for which to calculate the Gibson-Lanni PSF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[lambda,NA,magnification,pixelSize,indices,thicknesses,coverslipStepSize] = specifyStrehlDefaults();

% Determine the resolution with which to calculate rho. 
rhoResolution = 10000;

indices(1,2) = 1.3337;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate for each coverslip refractive index. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

results = cell(numel(refractiveIndexRange),1);

parfor j=1:numel(refractiveIndexRange)
	results{j} = calculateForIndex(rhoResolution,lambda,NA,magnification,pixelSize,indices,thicknesses,coverslipStepSize,refractiveIndexRange(j));
end


function results = calculateForIndex(rhoResolution,lambda,NA,magnification,pixelSize,indices,thicknesses,coverslipStepSize,coverslipRefractiveIndex)

%Start timing
tic

%Update
indices(2,2) = coverslipRefractiveIndex;

%While the objective NA may be higher, the effective NA for light 
%collection is the minimum of the objective NA and the actual refractive 
%indices.
NA = min(min(indices(:,2)),NA);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Determine which parameters we are varying. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Calculate the design optical path distance. 
designOPD = thicknesses(2,1)*indices(2,1)+thicknesses(3,1)*indices(3,1);

%Vary the coverslip thickness from 0 (the logical minimum) to the full 
%optical path thickness of the design system in 1 micron increments or the
%design thickness, whichever is greater
upperBound = floor(designOPD/indices(2,2));
upperBound = max(upperBound,sum(thicknesses(:,1)));
coverslipRange = 0:coverslipStepSize:upperBound;

%Determine the maximum reasonable immersion oil thickness, setting it as 
%1.5 times the full optical path thickness of the design system, rounded to
%the nearest micron. 
maxImmersion = floor(designOPD/indices(3,2)*1.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nThicknesses = numel(coverslipRange);
optimumImmersion = NaN(1,nThicknesses);

%Create a variable for use as we scan through the coverglass thickness
%range. 
currentThicknesses = thicknesses;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the optimum focus for the remaining coverslip thickness. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:nThicknesses
	%Set the current value
	currentThicknesses(2,2) = coverslipRange(j);
	
	if j>=3
		%Estimate the optimum based upon a linear extrapolation from the prior
		%two optima
		bestGuess = optimumImmersion(j-1)+(optimumImmersion(j-1)-optimumImmersion(j-2));
		bestGuess = max(bestGuess,0);
	else
		bestGuess = NaN;
	end
	
	optimumImmersion(j) = exploreOptimumFocus(indices,currentThicknesses,lambda,NA,magnification,maxImmersion,rhoResolution,bestGuess);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now, calculate the full Gibson-Lanni PSF for the optimum immersion oil
% thickness for each coverslip thickness. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[strehlRatio,ensquaredEnergy,GibsonLanniPSF,highResGibsonLanniPSF,isAccurate] = gibsonLanni(indices,thicknesses,lambda,NA,magnification,pixelSize,rhoResolution,optimumImmersion,coverslipRange);

if ~isAccurate
	warning('Strehl:Accuracy','The calculation was not run with sufficiently fine integration to produce accuarte results!')

	message = sprintf('The results are likely inaccurate! \n Try running at a higher accuracy level. ');
	msgbox(message,'Inaccurate Results','warn')
end

computationalTime = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Determine which results are actually needed. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Determine the locations of the maximum Strehl Ratio, maximum ensquared
%energy, and design coverslip thickness. 
[~,maxStrehlLoc] = max(strehlRatio);
[~,maxEELoc] = max(ensquaredEnergy);
designLoc = find(coverslipRange==170);
locations2Keep = unique([maxStrehlLoc maxEELoc designLoc]);

%Eliminate everything else
strehlRatio = strehlRatio(locations2Keep);
ensquaredEnergy = ensquaredEnergy(locations2Keep);
coverslipRange = coverslipRange(locations2Keep);
optimumImmersion = optimumImmersion(locations2Keep);
GibsonLanniPSF = GibsonLanniPSF(:,:,locations2Keep);
highResGibsonLanniPSF = highResGibsonLanniPSF(:,:,locations2Keep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Format the data for export. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Arrange the data as a structure, keeping all the relevant parameters
%accessible. 
nResults = numel(strehlRatio);
expander = ones(nResults,1);

%Create a structure for the indices of refraction
refractiveIndices = struct(	'designSample',		indices(1,1),...
							'designCoverslip',	indices(2,1),...
							'designImmersion',	indices(3,1),...
							'actualSample',		indices(1,2),...
							'actualCoverslip',	indices(2,2),...
							'actualImmersion',	indices(3,2)); 

%Create a structure for the layer thicknesses
layerThicknesses = struct(	'designSample',		thicknesses(1,1),...
							'designCoverslip',	thicknesses(2,1),...
							'designImmersion',	thicknesses(3,1),...
							'actualSample',		thicknesses(1,2),...
							'actualCoverslip',	num2cell(coverslipRange(:)),...
							'optimumImmersion',	num2cell(optimumImmersion(:))); 

%Convert to cells
strehlRatio = num2cell(strehlRatio(:));
ensquaredEnergy = num2cell(ensquaredEnergy(:));

%Separate out the PSFs
detectorPSF = squeeze(mat2cell(GibsonLanniPSF,size(GibsonLanniPSF,1),size(GibsonLanniPSF,2),expander));
highResolutionPSF = squeeze(mat2cell(highResGibsonLanniPSF,size(highResGibsonLanniPSF,1),size(highResGibsonLanniPSF,2),expander));

results = struct(	'strehlRatio',			strehlRatio,...
					'ensquaredEnergy',		ensquaredEnergy,...
					'detectorPSF',			detectorPSF,...
					'highResolutionPSF',	highResolutionPSF,...
					'isAccurate',			isAccurate,...
					'wavelength',			lambda,...
					'numericalAperture',	NA,...
					'magnification',		magnification,...
					'pixelSize',			pixelSize,...
					'computationalTime',	computationalTime,...
					'rhoInterval',			1/ceil(rhoResolution));

				
%Nest the structure appropriately. 
for j=1:nResults
	results(j).refractiveIndices = refractiveIndices;
	results(j).layerThicknesses = layerThicknesses(j);
end


function optimumImmersion = exploreOptimumFocus(indices,currentThicknesses,lambda,NA,magnification,maxImmersion,rhoResolution,bestGuess)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Speed things up by using an initial guess, often works. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~isnan(bestGuess)
	%We have an estimate of the optimum immersion oil thickness. Try this
	%as an estimate, using a fine scale (1 nm accuracy)
	guessWindow = .05;
	immersionRange = max((bestGuess-guessWindow),0):.001:(bestGuess+guessWindow);
	strehlRatio = gibsonLanni(indices,currentThicknesses,lambda,NA,magnification,0,rhoResolution,immersionRange);
	[~,loc] = max(strehlRatio);
	
	if loc~=1 || loc~=numel(immersionRange)
		optimumImmersion = immersionRange(loc);
		return
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The initial guess failed. Scan all possibilities. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Set the initial immersion range, scanning all possible thicknesses at the
%specified resolution
bounds = [0 maxImmersion];
resolution = 10; 

while resolution>=.001
	immersionRange = bounds(1):resolution:bounds(2);
	
	%Determine the Strehl ratio for this range at the specified resolution.
	strehlRatio = gibsonLanni(indices,currentThicknesses,lambda,NA,magnification,0,rhoResolution,immersionRange);
	
	%Determine the best guess for the immersion oil thickness. 
	[~,loc] = max(strehlRatio);
	bestGuess = immersionRange(loc);
	
	%Determine new bounds, allowing two resolution increments above and
	%below the current best guess. 
	bounds = [max(bestGuess-2*resolution,0) bestGuess+2*resolution];

	%Adjust the resolution to a finer resolution. 
	resolution = resolution/10;
end

optimumImmersion = bestGuess; 
