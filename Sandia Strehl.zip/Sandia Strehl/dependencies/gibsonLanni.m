function [strehlRatio,ensquaredEnergy,GibsonLanniPSF,highResGibsonLanniPSF,isAccurate] = gibsonLanni(indices,thicknesses,lambda,NA,magnification,pixelSize,rhoResolution,immersionRange,coverslipRange,sampleRange)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION [strehlRatio,ensquaredEnergy,GibsonLanniPSF,highResGibsonLanniPSF,isAccurate] = gibsonLanni(indices,thicknesses,lambda,NA,magnification,pixelSize,rhoResolution,immersionRange,coverslipRange,sampleRange)
%
% PURPOSE:
%	gibsonLanni is designed to efficiently calculate the Gibson-Lanni point
%	spread function (PSF) as well as some associated metrics (Strehl ratio,
%	ensquared energy) for the specified parameters. 
%
% DEPENDENCIES:
%	roundSigFigure.m
%	fastBinND.m
%	fastCounter.m
%	(calculateOpticalPathPart)
%	(combineRhoIndex)
%	(calcBesselPart)
%
% INPUTS:
%	indices:
%		The indices of refraction of the design (first column) and actual
%		(second column) imaging layers. 
%			(1,:)	The sample layer
%			(2,:)	The coverslip (glass) layer
%			(3,:)	The immersion media layer
%	thicknesses:
%		The thicknesses of the design (first column) and actual (second 
%		column) imaging layers. 
%			(1,:)	The sample layer
%			(2,:)	The coverslip (glass) layer
%			(3,:)	The immersion media layer%
%   lambda:
%		The wavelength of the light to be used for the point spread
%		function (PSF) calculation, in units of nm.
%	NA:
%		The numerical aperture of the microscope objective. 
%	magnification:
%		The magnification of the microscope objective. 
%	pixelSize:
%		The pixel size of the detector, in units of microns. This should be
%		the phyical pixel size of the detector; the magnification of the
%		objective will be employed to scale the PSF appropriately. 
%	rhoResolution: (Optional)
%		This value determines how many intervals rho will be divided into
%		for the calculation. Larger values are more accurate but more
%		computationally expensive. The default value for this is 1000. 
%	immersionRange:	(Optional)
%		If provided, this vector replaces the thickness of the immersion
%		oil layer provided in thicknesses. By allowing a vector,
%		the PSF can be calculated at the different values much more
%		efficiently since the bessel term does not change between the
%		different PSFs. If multiple optional inputs are provided, they 
%		must have the same size. 
%	coverslipRange:	(Optional)
%		If provided, this vector replaces the thickness of the coverslip
%		layer provided in thicknesses. By allowing a vector, the PSF can 
%		be calculated at the different values much more efficiently since 
%		the bessel term does not change between the different PSFs. If 
%		multiple optional inputs are provided, they must have the same 
%		size. 
%	sampleRange:	(Optional)
%		If provided, this vector replaces the thickness of the sample
%		layer provided in thicknesses. By allowing a vector, the PSF can 
%		be calculated at the different values much more efficiently since 
%		the bessel term does not change between the different PSFs. If 
%		multiple optional inputs are provided, they must have the same 
%		size. 
%
% OUTPUTS:
%	strehlRatio:
%		The Strehl ratio (ratio of the peak intensity of this PSF to the
%		peak intensity of a PSF of a perfect optical system with the same
%		aperture limited only by diffraction) for this PSF. If ranges were
%		provided for either the immersion oil layer thickness or coverslip
%		thickness, this output will be a vector of the corresponding size. 
%	ensquaredEnergy:
%		The ensquared energy (fraction of the total PSF energy within a
%		square of a given size centered on the centroid of the PSF) for 
%		this PSF for a square equal to the pixel size. If ranges were
%		provided for either the immersion oil layer thickness or coverslip
%		thickness, this output will be a vector of the corresponding size. 
%	GibsonLanniPSF:
%		The Gibson-Lanni PSF as it would be observed by a detector with
%		pixel size and magnification as specified. The PSF is centered at
%		the middle of the central pixel. If ranges were
%		provided for either the immersion oil layer thickness or coverslip
%		thickness, this output will be an image stack of the corresponding 
%		PSFs. 
%	highResGibsonLanniPSF:
%		As GibsonLanniPSF, except that the PSF is simulated at a higher
%		resolution and not downsampled to the pixel size. The degree of
%		resolution improvement is specified by the oversampleFactor
%		variable within the code. 
%	isAccurate:
%		Dividing the integration over rho into more values of rho produces
%		more accurate results, but is computationally more expensive. If 
%		the phase changes by more than 90 degrees between measurements, the
%		resulting calculation may be inaccurate. This condition is checked
%		for in the code. If this output is true, no issues were found. If
%		this output is false, the accuracy of the results should not be
%		trusted and the code should be rerun with a finer rho spacing. 
%
% REFERENCES:
%	1) Gibson, S. F. and F. Lanni (1991). "Experimental Test of an 
%		Analytical Model of Aberration in an Oil-Immersion Objective Lens 
%		Used in 3-Dimensional Light-Microscopy." Journal of the Optical 
%		Society of America a-Optics Image Science and Vision 8(10): 
%		1601-1613.
%	2) Born, M. and E. Wolf (1999). Principles of Optics. New York, 
%		Cambridge University Press.
%
% PROGRAMMER COMMENTS:
%	In this code, the design values are specified by the normal labels
%	(e.g. Ns) and the actual values are specified by prime (e.g. NsPrime).
%	In reference, the convention is often to have the design values
%	specified by a star (e.g. Ns* or n_s^* in Latex) and the actual values
%	specified with no modified (e.g. Ns or n_s in Latex)
%
% LIMITATIONS:
%	1) The code uses discrete approximations to calculate the integrals. 

% Revision History:
%	1.0.0, 09-20-2017, Stephen M. Anthony: Created. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract individual parameters and express all distance units in microns. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Ns = indices(1,1);	%Never needed
Ng = indices(2,1);
Ni = indices(3,1);
NsPrime = indices(1,2);
NgPrime = indices(2,2);
NiPrime = indices(3,2);

% Ts = thicknesses(1,1);	%Always 0, as such irrelevant
Tg = thicknesses(2,1);
Ti = thicknesses(3,1);
TsPrime = thicknesses(1,2);
TgPrime = thicknesses(2,2);
TiPrime = thicknesses(3,2);

%Convert from nm to microns. 
lambda = lambda/1000;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If we are trying to calculate at the best focus, vary the immersion oil
% (focus). Otherwise, use the exact value. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~exist('rhoResolution','var') || isempty(rhoResolution)
	rhoResolution = 1000;
end

%If the immersion oil range is specified, use that. 
if exist('immersionRange','var') && ~isempty(immersionRange)
	TiPrime = immersionRange;
end

%If the coverslip range is specified, use that. 
if exist('coverslipRange','var') && ~isempty(coverslipRange)
	TgPrime = coverslipRange;
end

%If the sample layer range is specified, use that. 
if exist('sampleRange','var') && ~isempty(sampleRange)
	TsPrime = sampleRange;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate other needed variables. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Create the integration variable. 
rhoInterval = 1/ceil(rhoResolution);
rho = (0:rhoInterval:1);
rho = rho';

if exist('pixelSize','var') && ~isempty(pixelSize) && logical(pixelSize)
	calculateFullPSF = true; 
	
	%Determine the location of the minima for the Airy disk
	% rayleighCriterion = 1.220*lambda/2/NA;
	% secondMinimum = 2.233*lambda/2/NA;
	thirdMinimum = 3.238*lambda/2/NA;
	% fourthMinimum = 4.242*lambda/2/NA;
	% fifthMinimum = 5.244*lambda/2/NA;
	modeledDistance = thirdMinimum;
% 	modeledDistance = rayleighCriterion;

	%Determine the effective pixel size (accounting for the magnification)
	effectivePixel = pixelSize/magnification;

	%Determine how many pixels are required to capture the third minima
	requiredPixels = ceil(modeledDistance/effectivePixel);
	requiredPixels = (2*requiredPixels+1); 
	
	%Construct a grid of coordinates within the pixel.
	oversampleFactor = 10; % must be even
	pixelRange = (0:1/oversampleFactor:requiredPixels)-requiredPixels/2; 
	pixelRange = pixelRange*effectivePixel;
	pixelDistance = sqrt(bsxfun(@plus,pixelRange(:).^2,pixelRange(:)'.^2));
	
	%Reduce to a reasonable number of significant figures. 
	pixelDistance = roundSigFigure(pixelDistance,12);
	
	%Determine the unique r values which must be calculated as symmettry
	%dictates an approximately 8-fold duplication
	[uniqueR,~,mapping] = unique(pixelDistance);
	uniqueR = uniqueR(:)';
	
	%Calculate the r values on a uniformly sampled r range, then
	%interpolate. 
	r2calculate = uniqueR(1):uniqueR(2)/2:uniqueR(end);
else
	calculateFullPSF = false;
	r2calculate = 0;
end

% k - a scalar
k = 2*pi/lambda;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the optical path distance portion of the integral
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%The first dimension is the integration variable rho. 
%The second dimension is the optical path condition. 
[OPDpart,isAccurate] = calculateOpticalPathPart(rho,k,NA,NsPrime,TsPrime,NgPrime,TgPrime,NiPrime,TiPrime,Ni,Ti,Ng,Tg); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the bessel portion of the integral. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%The first dimension is the integration variable rho. 
%The second dimension is the radial coordinate. 
besselPart = calcBesselPart(k,NA,rho,r2calculate);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Combine the OPDpart, besselPart, and rho to form part of the integrand. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%First, the optical design conditions must be moved to the fourth and 
%fifth dimensions.
OPDpart = permute(OPDpart,[1 3 2]);

%Next, multiply the OPDpart by rho. 
integrand = bsxfun(@times,OPDpart,rho);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform integration through the trapezoidal method. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initialize
highResGibsonLanniRadial = NaN(size(besselPart,2),size(OPDpart,3));
%The first dimension is the radial coordinate. 
%The second dimension is the optical path condition. 

if calculateFullPSF
	fastCounter(0,size(OPDpart,3),'Determining the PSF for condition %fast# of %fast#.')
end


for j=1:size(OPDpart,3)
	if calculateFullPSF
		fastCounter(j)
	end
	completeIntegrand = bsxfun(@times,integrand(:,:,j),besselPart);
	valueOfIntegral = (sum(completeIntegrand)-completeIntegrand(1,:)/2-completeIntegrand(end,:)/2)*rhoInterval;
	valueOfIntegral = valueOfIntegral(:);
	%To obtain the psf, multiply each element by its complex conjugate.
	highResGibsonLanniRadial(:,j) = valueOfIntegral.*conj(valueOfIntegral);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the Strehl ratio. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Multiplying by 4 causes the PSF of the design condition to peak at 1. 
highResGibsonLanniRadial = highResGibsonLanniRadial*4;
strehlRatio = highResGibsonLanniRadial(1,:)';

%Check for errors
if any(strehlRatio<=0) || any(roundSigFigure(max(strehlRatio),12)>1)
	error('gibsonLanni:Strehl','This should not be possible!')
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the PSF at each coverslip and immersion thickness pair
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if calculateFullPSF
	%Interpolate to all the desired grid points. 
	interpolatedGibsonLanni = interp1(r2calculate(:),highResGibsonLanniRadial,uniqueR(:));
	
	%Expand to all values
	highResGibsonLanniPSF = reshape(interpolatedGibsonLanni(mapping,:),[size(pixelDistance), numel(strehlRatio)]);
	
	%Perform trapezoidal integration, which will require four operations. 
	binFactors = [oversampleFactor oversampleFactor 1];
	binFactors = binFactors(1:ndims(highResGibsonLanniPSF));
	upperLeft = fastBinND(highResGibsonLanniPSF(1:end-1,1:end-1,:),binFactors);
	upperRight = fastBinND(highResGibsonLanniPSF(1:end-1,2:end,:),binFactors);
	lowerLeft = fastBinND(highResGibsonLanniPSF(2:end,1:end-1,:),binFactors);
	lowerRight = fastBinND(highResGibsonLanniPSF(2:end,2:end,:),binFactors);
	
	%Combine these to get the Gibson-Lanni PSF at the specified pixel
	%resolution. 
	GibsonLanniPSF = (upperLeft + upperRight + lowerLeft + lowerRight)/4/oversampleFactor^2;
	
	%Calculate the ensquared energy. Based upon an extended radius
	%calculation (100 times the distance to the third minimum, which should
	%capture 99.937439% of the total intensity), the total intensity within
	%that distance is .60211898515905894. As such, the total intensity to
	%infinity would be expected to be .602525. This is for NA 1.45,
	%magnification=60, lambda = 532. 
	normalization = .602525*(1.45^2)/(NA^2)/(60^2)*(magnification^2)/(.532^2)*(lambda^2);
	glPSFsize = size(GibsonLanniPSF);
	centerCoordinate = ceil(glPSFsize(1:2)/2);
 	ensquaredEnergy = squeeze(GibsonLanniPSF(centerCoordinate(1),centerCoordinate(2),:))/normalization;
	
	%Check for errors
	if any(ensquaredEnergy<=0) || any(ensquaredEnergy>1)
		error('gibsonLanni:Ensquared','This should not be possible!')
	end
end


function [OPDpart,isAccurate] = calculateOpticalPathPart(rho,k,NA,NsPrime,TsPrime,NgPrime,TgPrime,NiPrime,TiPrime,Ni,Ti,Ng,Tg)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check inputs for consistency. 
%	rho must be a vector
%	k and NA must be scalars
%	all other design conditions may be vectors or scalars. Any of these
%	which are vectors must have the same size. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Determine the number of elements in each input. 
inputCell = {rho,k,NA,NsPrime,TsPrime,NgPrime,TgPrime,NiPrime,TiPrime,Ni,Ti,Ng,Tg};
nElements = cellfun(@numel,inputCell);

%Check input size validity. 
if nElements(2)~=1 || nElements(3)~=1
	error('gibsonLanni:BadInputs','The lambda and NA variables must be scalars!')
end
%Find which of the remaining entries are vectors. 
nDesignElements = nElements(4:end);
if any(diff(nDesignElements(nDesignElements~=1)))
	error('gibsonLanni:BadInputs','All design element variables must either be vectors of the same size or scalars!')
end

%Force all elements to be vectors or scalars. For the vectors, rho should
%be a column vector; all others should be row vectors. 
rho = rho(:);
NsPrime = NsPrime(:)';
TsPrime = TsPrime(:)';
NgPrime = NgPrime(:)';
TgPrime = TgPrime(:)';
NiPrime = NiPrime(:)';
TiPrime = TiPrime(:)';
Ni = Ni(:)';
Ti = Ti(:)';
Ng = Ng(:)';
Tg = Tg(:)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform the actual calculation, using bxfun to expand as little as 
% possible until necessary. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%The overall expression we are trying to evaluate is:
% OPDpart = exp((1i*k)*...
% 	(NsPrime*TsPrime*sqrt(1-(NA*rho/NsPrime).^2)+...
% 	+NgPrime*TgPrime*sqrt(1-(NA*rho/NgPrime).^2)+...
% 	+NiPrime*TiPrime*sqrt(1-(NA*rho/NiPrime).^2)-...
% 	-Ni*Ti*sqrt(1-(NA*rho/Ni).^2)-...
% 	-Ng*Tg*sqrt(1-(NA*rho/Ng).^2)));
%The following code makes use of the bxfun to expand as little as possible
%until necessary. 

%Combine NA and rho as they always occur together. 
NArho = NA*rho;

%Calculate the following expressions
%	nThis*sqrt(1-(NA*rho/nThis).^2);
riSamplePrime = bsxfun(@combineRhoIndex,NArho,NsPrime);
riGlassPrime = bsxfun(@combineRhoIndex,NArho,NgPrime);
riImmersionPrime = bsxfun(@combineRhoIndex,NArho,NiPrime);
riImmersion = bsxfun(@combineRhoIndex,NArho,Ni);
riGlass = bsxfun(@combineRhoIndex,NArho,Ng);

%Append the thicknesses
%	nThis*tThis*sqrt(1-(NA*rho/nThis).^2);
samplePrimePart = bsxfun(@times,TsPrime,riSamplePrime);
glassPrimePart = bsxfun(@times,TgPrime,riGlassPrime);
immersionPrimePart = bsxfun(@times,TiPrime,riImmersionPrime);
immersionPart = bsxfun(@times,Ti,riImmersion);
glassPart = bsxfun(@times,Tg,riGlass);

%Generate the exponent. Add each component in turn. 
exponent = bsxfun(@plus,samplePrimePart,glassPart);
exponent = bsxfun(@plus,exponent,immersionPart);
exponent = bsxfun(@minus,exponent,immersionPrimePart);
exponent = bsxfun(@minus,exponent,glassPrimePart);

%If the phase changes by more than 90 degrees between measurements, the
%resulting calculation may be inaccurate. Validate. 
isAccurate = max(max(diff(exponent)))/(2*pi)<.25; 

%Calculate the exponential portion
OPDpart = exp((1i*k)*exponent);


function rhoIndex = combineRhoIndex(NArho,nThis)

rhoIndex = nThis*sqrt(1-(NArho/nThis).^2);


function besselPart = calcBesselPart(k,NA,rho,r)

besselTerm = bsxfun(@times,k*NA*rho,r);

besselPart = besselj(0,besselTerm);
