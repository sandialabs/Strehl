function [lambda,NA,magnification,pixelSize,indices,thicknesses,coverslipStepSize] = specifyStrehlDefaults()

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION [lambda,NA,magnification,pixelSize,indices,thicknesses] = specifyStrehlDefaults()
%
% PURPOSE:
%	specifyStrehlDefaults is designed to conveniently specify all the
%	default values for Strehl.m GUI, grouping them in one place. 
%
% DEPENDENCIES:
%	-None-
%
% INPUTS:
%	-None-
%
% OUTPUTS:
%   lambda:
%		The wavelength of the light to be used for the point spread
%		function (PSF) calculation, in units of nm.
%	NA:
%		The numerical aperture of the microscope objective. 
%	magnification:
%		The magnification of the microscope objective. 
%	pixelSize:
%		The pixel size of the detector, in units of microns. This should be
%		the phyical pixel size of the detector; the magnification of the
%		objective will be employed to scale the PSF appropriately. 
%	indices:
%		The indices of refraction of the design (first column) and actual
%		(second column) imaging layers. 
%			(1,:)	The sample layer
%			(2,:)	The coverslip (glass) layer
%			(3,:)	The immersion media layer
%	thicknesses:
%		The thicknesses of the design (first column) and actual (second 
%		column) imaging layers. 
%			(1,:)	The sample layer
%			(2,:)	The coverslip (glass) layer
%			(3,:)	The immersion media layer
%	coverslipStepSize:
%		The step size to use when varying the coverslip thickness. 
%
% REFERENCES:
%	1) Gibson, S. F. and F. Lanni (1991). "Experimental Test of an 
%		Analytical Model of Aberration in an Oil-Immersion Objective Lens 
%		Used in 3-Dimensional Light-Microscopy." Journal of the Optical 
%		Society of America a-Optics Image Science and Vision 8(10): 
%		1601-1613.
%	2) Index of refraction of Olympus Type F immersion oil
%		https://www.thorlabs.com/newgrouppage9.cfm?objectgroup_id=5381
%	3) Index of refraction and thickness of ISO 8255-1 #1.5 coverslips
%		https://www.tedpella.com/histo_html/coverslip-info.htm
%
% PROGRAMMER COMMENTS:
%	In this code, the design values are specified by the normal labels
%	(e.g. Ns) and the actual values are specified by prime (e.g. NsPrime).
%	In reference, the convention is often to have the design values
%	specified by a star (e.g. Ns* or n_s^* in Latex) and the actual values
%	specified with no modified (e.g. Ns or n_s in Latex)
%
% LIMITATIONS:
%	1) The indices of refraction have been adjusted to 532 nm by accounting
%		for the dispersion. The formula used for this assumes that the
%		dispersion is linear over the regime. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Specify the default values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Specify the step size (microns) when varying the coverslip thickness. 
coverslipStepSize = .1;

%Microscope Parameters
lambda = 532;
NA = 1.45;
magnification = 60;
pixelSize = 16;

%Design Indices
Ns = NaN;	
Ng = 1.5263;	%ISO 8255-1 Coverslip (https://www.tedpella.com/histo_html/coverslip-info.htm), accounting for dispersion to 532 nm
Ni = 1.5190;	%Olympus Type F immersion oil - https://www.thorlabs.com/newgrouppage9.cfm?objectgroup_id=5381, accounting for dispersion to 532 nm

%Design Thicknesses
Ts = 0;
Tg = 170;		%ISO 8255-1 #1.5 Coverslip (https://www.tedpella.com/histo_html/coverslip-info.htm)
Ti = 150;

%Actual Indices
NsPrime = 1.5190;
NgPrime = 1.5263;
NiPrime = 1.5190;

%Actual Thicknesses
TsPrime = 0;
TgPrime = 170;
TiPrime = 150;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Combine the thicknesses and indices into single variables. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

thicknesses = [[Ts TsPrime]; [Tg TgPrime]; [Ti TiPrime]];
indices = [[Ns NsPrime]; [Ng NgPrime]; [Ni NiPrime]];