function arr = fastBinND(arr,binFactors)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION arr = fastBinND(arr,binFactors)
%
% PURPOSE:
%	fastBinND is designed to take an array and bin it along its various
%	dimensions by the factors specified. 
%
% DEPENDENCIES:
%	-None-
%
% INPUTS:
%   arr:
%       An ND array. 
%	binFactors:
%		The factor by which each dimension should be binned. If only a
%		single value is provided, all dimensions are binned by that value.
%		If multiple values are provided, one per dimension of the input
%		arr, than each dimension is binned by the corresponding factor. 
%		All values must be positive numbers which are factors of the size
%		of their respective dimensions. 
%
% OUTPUTS:
%   arr:
%       The output ND array, binned as desired. 
%
% REFERENCES:
%	-None-
%
% PROGRAMMER COMMENTS:
%	-None-
%
% LIMITATIONS:
%	-None-

%Determine the current size and dimensionality
arrSize = size(arr)';
nDims = numel(arrSize);

%Check the inputs and expand binFactors if necessary
if numel(binFactors) == 1
	binFactors = ones(nDims,1)*binFactors;
elseif  numel(binFactors) == nDims
	binFactors = binFactors(:);
else
	error('fastBinND:badInput','The dimensions of the input array and the binFactors do not match!')
end

%Initialize needed values for later
finalSize = arrSize(:)./binFactors;
dimNumbers  = 1:nDims;

%Loop through the dimensions, binning along each one which needs to be. 
dim2opOn = find(binFactors~=1);
if isempty(dim2opOn)
	%No binning necessary. 
	return
end
for i=1:numel(dim2opOn)
	j = dim2opOn(i);
	%Construct forward and reverse mappings
	forMapping = [j dimNumbers(dimNumbers~=j)];
	revMapping = [dimNumbers(2:j) 1 dimNumbers(j+1:end)];
	
	%Set the dimension order such that the dimension we are working on is
	%the first dimension
	arr = permute(arr,forMapping);
	
	%Reshape such that each column is one bin
	arr = reshape(arr,binFactors(j),[]);
	
	%Sum to bin
	arr = sum(arr,1);
	
	%Determine what the current array dimensions should be in normal order
	currSize = [finalSize(1:j); arrSize(j+1:end);]';
	
	%Reshape back to normal dimensions
 	arr = reshape(arr,currSize(forMapping));
	
	%Permute back to the original arrangement
	arr = permute(arr,revMapping);
end