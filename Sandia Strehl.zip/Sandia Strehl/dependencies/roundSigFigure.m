function output = roundSigFigure(values,N)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
% FUNCTION output = roundSigFigure(values,N)
%
% PURPOSE:
%   Rounds numbers off to a specified number of signifcant figures
%   (which allows comparisons of equality without the nuisance of machine
%   inprecision)
%
% DEPENDENCIES:
%   -None-
%
%
% INPUTS:
%   values
%     an n-dimensional array of values to be rounded
%   N
%     the number of significant figure to round to
%
% OUTPUTS:
%   output:
%     The input values rounded to the specified number of specific figures.
%
% REFERENCES:
%	-None-
%
% PROGRAMMER COMMENTS:
%	While the same functionality is available builltin to matlab:
%		output = round(values,N,'significant')
%	my code is significantly (>5 times) faster when there are a large
%	number of entries in values. 
%
% LIMITATIONS:
%	-None-

%Determine the sign of all terms
theSign=sign(values);

%Make all values positive, easier to work with for now
values=abs(values);

%First, we need to find the location of the largest digit
digit=floor(log10(values))+1;
%For example:
%   1   = ones digit
%   3   = thousands digit
%   9   = billions digit
%   0   = tenths digit
%   -3  = ten-thousandths digit

%Adjust all numbers so that the last significant digit we want is in the
%ones place
scaled      = values.*(10.^-(digit-N));

%Now that the last digit we want is in the ones place, we can safely round
%the values
sigScaled   = round(scaled);

%Revert to the proper power and proper sign
output      = sigScaled.*(10.^(digit-N)).*theSign;

%Correct for zero terms
output(theSign==0) = 0;