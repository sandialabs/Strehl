function varargout = SandiaStrehl(varargin)

%Copyright 2017 National Technology & Engineering Solutions of Sandia, 
%LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS, the 
%U.S. Government retains certain rights in this software.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     (1) Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer. 
% 
%     (2) Redistributions in binary form must reproduce the above copyright
%     notice, this list of conditions and the following disclaimer in
%     the documentation and/or other materials provided with the
%     distribution.  
%     
%     (3)The name of the author may not be used to
%     endorse or promote products derived from this software without
%     specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
% IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
% INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
% STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
% IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
%FUNCTION SandiaStrehl()
%
% PURPOSE:
%	The Sandia SandiaStrehl GUI is designed to conveniently calculate the effect
%	of non-design image conditions (primarily non-design refractive indices
%	or thicknesses) on the image quality (measured by the SandiaStrehl ratio and
%	ensquared energy). Additionally, it will calculate the entire PSF for
%	the specified conditions. 
%
% DEPENDENCIES:
%	specifyStrehlDefaults.m
%	gibsonLanni.m
%	roundSigFigure.m
%	fastBinND.m
%	fastCounter.m
%
% INPUTS:
%	-None-
%
% OUTPUTS: (with Export Button - assigns in base workspace)
%	Sandia_Strehl_Scan_Thickness_Results:
%		A structure, where each element of the structure gives the results
%		for a specific coverslip thickness. The code automatically tries
%		all plausible coverslip thicknesses and finds the optimum immersion
%		oil thickness for each one. The fields are:
%			strehlRatio:
%				The SandiaStrehl ratio for the corresponding parameters. 
%			ensquaredEnergy:
%				The ensquared energy for the corresponding parameters. 
%			detectorPSF:
%				The PSF for the corresponding parameters with pixels size
%				as specified for the detector. 
%			highResolutionPSF:
%				The PSF for the corresponding parameters calculated at a
%				higher resolution than the detector. Experience has shown
%				it is necessary to calculate at a higher resolution and
%				integrate; calculating at only one discrete point per pixel
%				can give inaccurate results. 
%			isAccurate:
%				A Boolean value. If false, the results are likely
%				inaccurate; the code should be run with a higher accuracy
%				setting (finer resolution for rho). 
%			wavelength:
%				The wavelength of light for which the PSF was simulated in
%				nm. 
%			numericalAperture:
%				The numerical aperture of the microscope objective. Note,
%				the effective NA may be smaller if a layer has a lower
%				refractive index. 
%			magnification:
%				The magnification of the microscope (objective plus any
%				additional magnification). 
%			pixelSize:
%				The pixel size of the detector in microns. 
%			computationalTime:
%				The time in seconds required to calculate the whole range. 
%			rhoInterval:
%				Rho is divided into steps 0:1/rhoInterval:1. More steps
%				takes longer, but too few steps may be inaccruate. 
%			refractiveIndices:
%				A sub structure with the refractive indices, both design
%				and actual, for the various layers. 
%			layerThicknesses:
%				A sub structure with the layer thicknesses, both design
%				and actual, for the various layers. Note that no actual
%				layer thickness is given for the immersion layer; instead
%				the optimum immersion layer thickness is given. The optimum
%				immersion layer thickness is the immersion layer thickness
%				that maximizes the SandiaStrehl ratio for the other specified
%				parameters. 
%	Sandia_Strehl_Specific_Condition_Results:
%		As Sandia_Strehl_Scan_Thickness_Results, except that it is
%		calculated for exactly the values specified in the GUI.
%		Sandia_Strehl_Scan_Thickness_Results scans the range of potential
%		coverslip thicknesses and finds the optimum immersion oil thickness
%		for each result. Sandia_Strehl_Specific_Condition_Results uses the
%		exact coverslip thickness and immersion oil thickness specified by
%		the GUI, even if this is not an optimum combination or a convenient
%		interval point. 
%
% REFERENCES:
%	1) Gibson, S. F. and F. Lanni (1991). "Experimental Test of an 
%		Analytical Model of Aberration in an Oil-Immersion Objective Lens 
%		Used in 3-Dimensional Light-Microscopy." Journal of the Optical 
%		Society of America a-Optics Image Science and Vision 8(10): 
%		1601-1613.
%	2) Born, M. and E. Wolf (1999). Principles of Optics. New York, 
%		Cambridge University Press.
%
% PROGRAMMER COMMENTS:
%	In this code, the design values are specified by the normal labels
%	(e.g. Ns) and the actual values are specified by prime (e.g. NsPrime).
%	In reference, the convention is often to have the design values
%	specified by a star (e.g. Ns* or n_s^* in Latex) and the actual values
%	specified with no modified (e.g. Ns or n_s in Latex)
%
% LIMITATIONS:
%	1) The code uses discrete approximations to calculate the integrals. 

% Last Modified by GUIDE v2.5 08-May-2019 15:23:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SandiaStrehl_OpeningFcn, ...
                   'gui_OutputFcn',  @SandiaStrehl_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes just before SandiaStrehl is made visible.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function SandiaStrehl_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<*VANUS>

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the default values and set them. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[lambda,NA,magnification,pixelSize,indices,thicknesses] = specifyStrehlDefaults(); 
setParameters(handles,lambda,NA,magnification,pixelSize,indices,thicknesses);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize shared values. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

setappdata(handles.Sandia_GibsonLanni_GUI,'FigureHandle',[]);
setappdata(handles.Sandia_GibsonLanni_GUI,'Results',[]);
setappdata(handles.Sandia_GibsonLanni_GUI,'specificResults',[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose default command line output for SandiaStrehl
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GUI Closing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = SandiaStrehl_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes during object creation, after setting all properties.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function objectCreationFcn(hObject, eventdata, handles) %#ok<*INUSD,*DEFNU>

set(hObject,'BackgroundColor','white');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Selections which only change parameters for calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function editParameters_Callback(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract all the parameters. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[lambda,NA,magnification,pixelSize,indices,thicknesses] = determineCurrentParameters(handles); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set all the parameters. While this may seem largely redundant, it ensures
% the display is consistent with the values being read. Also, the
% str2double step paired with num2str will remove many bad inputs. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

setParameters(handles,lambda,NA,magnification,pixelSize,indices,thicknesses)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Disable the calculation button and export button until revalidated. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(handles.pushCalculate,'Enable','Off')
set(handles.pushExport,'Enable','Off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mode selections (which change which fields are active. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function buttonMode_Callback(hObject, eventdata, handles)

isTIRF = get(handles.buttonTIRF,'Value');
isEPi = get(handles.buttonEpi,'Value');

if isTIRF && ~isEPi
	%Actual sample thickness must be 0. 
	set(handles.editTsPrime,'Enable','off')
	set(handles.editTsPrime,'String',num2str(0))
elseif ~isTIRF && isEPi
	%Actual sample thickness can be relevant
	set(handles.editTsPrime,'Enable','on')
else
	error('Strehl:RadioFail','The radio button should never be able to enter this state!')
end

%Reset. 
set(handles.pushCalculate,'Enable','Off')
set(handles.pushExport,'Enable','Off')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Operations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pushValidate_Callback(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract all the variables. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[lambda,NA,magnification,pixelSize,indices,thicknesses] = determineCurrentParameters(handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the default values in case they are needed. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[defaultLambda,defaultNA,defaultMagnification,defaultPixelSize,defaultIndices,defaultThicknesses] = specifyStrehlDefaults(); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract the individual thicknesses and indices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ts = thicknesses(1,1);
TsPrime = thicknesses(1,2);
Tg = thicknesses(2,1);
TgPrime = thicknesses(2,2);
Ti = thicknesses(3,1);
TiPrime = thicknesses(3,2);

Ns = indices(1,1);
NsPrime = indices(1,2);
Ng = indices(2,1);
NgPrime = indices(2,2);
Ni = indices(3,1);
NiPrime = indices(3,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine whether each layer thickness input is reasonable (white), 
% surprising (yellow), or nonsense (red).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initialize
anySurprising = false;
anyNonsense = false;


if Ts~=0
	error('Strehl:ValidateTs','This should not be possible!')
end

if isnan(Tg) || isempty(Tg) || Tg<0
	%Negative, empty, or NaN thicknesses make no sense! Reset this to the
	%default value. 
	anyNonsense = true;
	set(handles.editTg,'BackgroundColor','red','String',num2str(defaultThicknesses(2,1)));
elseif Tg>300 || Tg<10
	%Coverslips will usually be 10's to 100's of microns thick. Is the
	%entry in the wrong units? 
	anySurprising = true; 
	set(handles.editTg,'BackgroundColor','yellow');
else
	set(handles.editTg,'BackgroundColor','white');
end

if isnan(Ti) || isempty(Ti) || Ti<0
	%Negative, empty, or NaN thicknesses make no sense! Reset this to the
	%default value. 
	anyNonsense = true;
	set(handles.editTi,'BackgroundColor','red','String',num2str(defaultThicknesses(3,1)));
elseif Ti>300 || Ti<10
	%Immersion layers will usually be 10's to 100's of microns thick. Is 
	%the entry in the wrong units? 
	anySurprising = true; 
	set(handles.editTi,'BackgroundColor','yellow');
else
	set(handles.editTi,'BackgroundColor','white');
end

if isnan(TsPrime) || isempty(TsPrime) || TsPrime<0
	%Negative, empty, or NaN thicknesses make no sense! Reset this to the
	%default value. 
	anyNonsense = true;
	set(handles.editTsPrime,'BackgroundColor','red','String',num2str(defaultThicknesses(1,2)));
elseif TsPrime>50
	%Sample thickness will usually be less than 50 micron thick. Is the
	%entry in the wrong units? 
	anySurprising = true; 
	set(handles.editTsPrime,'BackgroundColor','yellow');
else
	set(handles.editTsPrime,'BackgroundColor','white');
end

if isnan(TgPrime) || isempty(TgPrime) || TgPrime<0
	%Negative, empty, or NaN thicknesses make no sense! Reset this to the
	%default value. 
	anyNonsense = true;
	set(handles.editTgPrime,'BackgroundColor','red','String',num2str(defaultThicknesses(2,2)));
elseif TgPrime>300 || TgPrime<10
	%Coverslips will usually be 10's to 100's of microns thick. Is the
	%entry in the wrong units? 
	anySurprising = true; 
	set(handles.editTgPrime,'BackgroundColor','yellow');
else
	set(handles.editTgPrime,'BackgroundColor','white');
end

if isnan(TiPrime) || isempty(TiPrime) || TiPrime<0
	%Negative, empty, or NaN thicknesses make no sense! Reset this to the
	%default value. 
	anyNonsense = true;
	set(handles.editTiPrime,'BackgroundColor','red','String',num2str(defaultThicknesses(3,2)));
elseif TiPrime>300 || TiPrime<10
	%Immersion layers will usually be 10's to 100's of microns thick. Is 
	%the entry in the wrong units? 
	anySurprising = true; 
	set(handles.editTiPrime,'BackgroundColor','yellow');
else
	set(handles.editTiPrime,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine whether each index of refraction input is reasonable (white), 
% surprising (yellow), or nonsense (red).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if Ns~=Ni
	error('Strehl:ValidateNs','This should not be possible!')
end

if isnan(Ng) || isempty(Ng) || Ng<.1 || Ng>4
	%Values <.1 or >4 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNg,'BackgroundColor','red','String',num2str(defaultIndices(2,1)));
elseif Ng>1.8 || Ng<1.3
	%Coverslip indices of refraction will usually be between 1.3 and 1.8. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNg,'BackgroundColor','yellow');
else
	set(handles.editNg,'BackgroundColor','white');
end

if isnan(Ni) || isempty(Ni) || Ni<.1 || Ni>4
	%Values <.1 or >4 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNi,'BackgroundColor','red','String',num2str(defaultIndices(3,1)));
	%Ns should always equal Ni
	set(handles.editNs,'BackgroundColor','red','String',num2str(defaultIndices(3,1)));
elseif Ni>1.8 || Ni<1
	%Immersion indices of refraction will usually be between 1 and 1.8. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNi,'BackgroundColor','yellow');
else
	set(handles.editNi,'BackgroundColor','white');
end

if isnan(NsPrime) || isempty(NsPrime) || NsPrime<.1 || NsPrime>4
	%Values <.1 or >4 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNsPrime,'BackgroundColor','red','String',num2str(defaultIndices(1,2)));
elseif NsPrime>1.8 || NsPrime<1
	%Sample indices of refraction will usually be between 1 and 1.8. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNsPrime,'BackgroundColor','yellow');
else
	set(handles.editNsPrime,'BackgroundColor','white');
end

if isnan(NgPrime) || isempty(NgPrime) || NgPrime<.1 || NgPrime>4
	%Values <.1 or >4 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNgPrime,'BackgroundColor','red','String',num2str(defaultIndices(2,2)));
elseif NgPrime>1.8 || NgPrime<1.3
	%Coverslip indices of refraction will usually be between 1.3 and 1.8. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNgPrime,'BackgroundColor','yellow');
else
	set(handles.editNgPrime,'BackgroundColor','white');
end

if isnan(NiPrime) || isempty(NiPrime) || NiPrime<.1 || NiPrime>4
	%Values <.1 or >4 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNiPrime,'BackgroundColor','red','String',num2str(defaultIndices(3,2)));
elseif NiPrime>1.8 || NiPrime<1
	%Immersion indices of refraction will usually be between 1 and 1.8. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNiPrime,'BackgroundColor','yellow');
else
	set(handles.editNiPrime,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine whether each microscope parameter input is reasonable (white), 
% surprising (yellow), or nonsense (red).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isnan(NA) || isempty(NA) || NA<=0 || NA>2
	%Values <=0 or >2 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editNA,'BackgroundColor','red','String',num2str(defaultNA));
elseif NA>1.8 || NA<.05
	%Numerical aperture will usually be around 1.4-1.5. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editNA,'BackgroundColor','yellow');
else
	set(handles.editNA,'BackgroundColor','white');
end

if isnan(magnification) || isempty(magnification) || magnification<1 || magnification>1000
	%Values <1 or >1000 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editMagnification,'BackgroundColor','red','String',num2str(defaultMagnification));
elseif magnification>250 || magnification<40
	%Magnification will usually be around 40-250. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editMagnification,'BackgroundColor','yellow');
else
	set(handles.editMagnification,'BackgroundColor','white');
end

if isnan(pixelSize) || isempty(pixelSize) || pixelSize<0 || pixelSize>1000
	%Values <0 or >1000 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editPixel,'BackgroundColor','red','String',num2str(defaultPixelSize));
elseif pixelSize>25 || pixelSize<2
	%Pixel size will usually be around 2-25 microns. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editPixel,'BackgroundColor','yellow');
else
	set(handles.editPixel,'BackgroundColor','white');
end

if isnan(lambda) || isempty(lambda) || lambda<1 || lambda>10000
	%Values <1 or >10000 make no sense. Reset this to the default value. 
	anyNonsense = true;
	set(handles.editWavelength,'BackgroundColor','red','String',num2str(defaultLambda));
elseif lambda>900 || lambda<300
	%Wavelength will usually be around 300-900 nanometers. 
	%Is the value correct? 
	anySurprising = true; 
	set(handles.editWavelength,'BackgroundColor','yellow');
else
	set(handles.editWavelength,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check whether the effective NA is lower due to other inputs. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Parameters may have been changed. Update to the latest values. 
[~,NA,~,~,indices] = determineCurrentParameters(handles);

%Initialize
otherIssue = false;

if any(indices(:,1)<NA)
	message = sprintf('It should not be possible to design a microscope objective where any\n of the design indices of refraction are less than the NA. ');
	msgbox(message,'Design Issues')
	otherIssue = true;
end

isTIRF = get(handles.buttonTIRF,'Value');

if isTIRF && (indices(1,2)>=NA || indices(1,2)>=indices(2,2) || indices(1,2)>=indices(3,2))
	message = sprintf('TIRF can only occur if the index of refraction\n of the sample is less than the NA and the index \n of refraction of the coverslip and immersion. ');
	msgbox(message,'TIRF Impossible')
	otherIssue = true;
end

if any(indices(:,2)<NA)
	message = sprintf('While the objective NA may be higher, the effective\n NA for light collection is the minimum of \n the objective NA and the actual refractive indices. ');
	msgbox(message,'Effective NA')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If any parameters were surprising or nonsense, display a messagebox. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if anySurprising || anyNonsense
	message = sprintf('Some inputs were either unexpected or nonsense.\n Unexpected inputs were marked in yellow.\n Nonsense inputs were marked in red and replaced with default values.');
	msgbox(message,'Surprising Inputs')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If there were no nonsense parameters, enable the calulcation button. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~anyNonsense && ~otherIssue
	set(handles.pushCalculate,'Enable','On')
else
	set(handles.pushCalculate,'Enable','Off')
end
set(handles.pushExport,'Enable','Off')


function pushCalculate_Callback(hObject, eventdata, handles)

%Start timing
tic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the resolution with which to calculate rho. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goodResolution = get(handles.radioGood,'Value');
betterResolution = get(handles.radioBetter,'Value');
bestResolution = get(handles.radioBest,'Value');

if goodResolution+betterResolution+bestResolution~=1
	error('Strehl:AccuracyButton','This should not be possible!')
elseif goodResolution
	rhoResolution = 1000;
elseif betterResolution
	rhoResolution = 10000;
elseif bestResolution
	rhoResolution = 100000;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the parameters for which to calculate the Gibson-Lanni PSF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[lambda,NA,magnification,pixelSize,indices,thicknesses] = determineCurrentParameters(handles); 
[~,~,~,~,~,~,coverslipStepSize] = specifyStrehlDefaults();

%While the objective NA may be higher, the effective NA for light 
%collection is the minimum of the objective NA and the actual refractive 
%indices.
NA = min(min(indices(:,2)),NA);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Determine which parameters we are varying. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Calculate the design optical path distance. 
designOPD = thicknesses(2,1)*indices(2,1)+thicknesses(3,1)*indices(3,1);

%Vary the coverslip thickness from 0 (the logical minimum) to the full 
%optical path thickness of the design system in 1 micron increments or the
%design thickness, whichever is greater
upperBound = floor(designOPD/indices(2,2));
upperBound = max(upperBound,sum(thicknesses(:,1)));
coverslipRange = 0:coverslipStepSize:upperBound;

%Determine the maximum reasonable immersion oil thickness, setting it as 
%1.5 times the full optical path thickness of the design system, rounded to
%the nearest micron. 
maxImmersion = floor(designOPD/indices(3,2)*1.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nThicknesses = numel(coverslipRange);
optimumImmersion = NaN(1,nThicknesses);

%Create a variable for use as we scan through the coverglass thickness
%range. 
currentThicknesses = thicknesses;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the optimum focus. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fastCounter(0,nThicknesses,'Determining the optimum immersion thickness for coverslip thickness %fast# of %fast#.')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the optimum focus for the remaining coverslip thickness. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:nThicknesses
	fastCounter(j)
	%Set the current value
	currentThicknesses(2,2) = coverslipRange(j);
	
	if j>=3
		%Estimate the optimum based upon a linear extrapolation from the prior
		%two optima
		bestGuess = optimumImmersion(j-1)+(optimumImmersion(j-1)-optimumImmersion(j-2));
		bestGuess = max(bestGuess,0);
	else
		bestGuess = NaN;
	end
	
	optimumImmersion(j) = exploreOptimumFocus(indices,currentThicknesses,lambda,NA,magnification,maxImmersion,rhoResolution,bestGuess);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now, calculate the full Gibson-Lanni PSF for the optimum immersion oil
% thickness for each coverslip thickness. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[strehlRatio,ensquaredEnergy,GibsonLanniPSF,highResGibsonLanniPSF,isAccurate] = gibsonLanni(indices,thicknesses,lambda,NA,magnification,pixelSize,rhoResolution,optimumImmersion,coverslipRange);

if ~isAccurate
	warning('Strehl:Accuracy','The calculation was not run with sufficiently fine integration to produce accuarte results!')

	message = sprintf('The results are likely inaccurate! \n Try running at a higher accuracy level. ');
	msgbox(message,'Inaccurate Results','warn')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now, calculate the full Gibson-Lanni PSF for the exact actual conditions
% provided by the user. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[exactStrehlRatio,exactEnsquaredEnergy,exactGibsonLanniPSF,exactHighResGibsonLanniPSF,isExactAccurate] = gibsonLanni(indices,thicknesses,lambda,NA,magnification,pixelSize,rhoResolution);

if ~isExactAccurate
	warning('Strehl:Accuracy','The calculation was not run with sufficiently fine integration to produce accuarte results!')

	message = sprintf('The results are likely inaccurate! \n Try running at a higher accuracy level. ');
	msgbox(message,'Inaccurate Results','warn')
end


%Finish timing 
computationalTime = toc; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Display the pertinent results. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figHandle = getappdata(handles.Sandia_GibsonLanni_GUI,'FigureHandle');
if ~isempty(figHandle) && ishandle(figHandle)
	figure(figHandle);
else
	figHandle = figure;
end
setappdata(handles.Sandia_GibsonLanni_GUI,'FigureHandle',figHandle);

FigFont = 14; 
AxisFont = 18;
DataLineWidth = 1.5; 
AxisWidth = 1; 

subplot(2,1,1)
plot(coverslipRange,strehlRatio,'linewidth', DataLineWidth)
axis([min(coverslipRange) max(coverslipRange) max(min(strehlRatio*.9),0) min(max(strehlRatio*1.1),1)])
xlabel('Coverslip Thickness (\mum)')
ylabel('Strehl Ratio')
set(gca,'fontsize', FigFont)
set(get(gca, 'xlabel'),'fontsize', AxisFont)
set(get(gca, 'ylabel'),'fontsize', AxisFont)
set(gca, 'linewidth', AxisWidth)
box on
grid on

subplot(2,1,2)
plot(coverslipRange,ensquaredEnergy,'linewidth', DataLineWidth)
axis([min(coverslipRange) max(coverslipRange) max(min(ensquaredEnergy*.9),0) min(max(ensquaredEnergy*1.1),1)])
set(gca,'fontsize', FigFont)
xlabel('Coverslip Thickness (\mum)')
ylabel('Ensquared Energy')
set(get(gca, 'xlabel'),'fontsize', AxisFont)
set(get(gca, 'ylabel'),'fontsize', AxisFont)
set(gca, 'linewidth', AxisWidth)
box on
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Format the data for export. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Arrange the data as a structure, keeping all the relevant parameters
%accessible. 
nResults = numel(strehlRatio);
expander = ones(nResults,1);

%Create a structure for the indices of refraction
refractiveIndices = struct(	'designSample',		indices(1,1),...
							'designCoverslip',	indices(2,1),...
							'designImmersion',	indices(3,1),...
							'actualSample',		indices(1,2),...
							'actualCoverslip',	indices(2,2),...
							'actualImmersion',	indices(3,2)); 

%Create a structure for the layer thicknesses
layerThicknesses = struct(	'designSample',		thicknesses(1,1),...
							'designCoverslip',	thicknesses(2,1),...
							'designImmersion',	thicknesses(3,1),...
							'actualSample',		thicknesses(1,2),...
							'actualCoverslip',	num2cell(coverslipRange(:)),...
							'optimumImmersion',	num2cell(optimumImmersion(:))); 

%Create a structure for the layer thicknesses
specificThicknesses = struct('designSample',	thicknesses(1,1),...
							'designCoverslip',	thicknesses(2,1),...
							'designImmersion',	thicknesses(3,1),...
							'actualSample',		thicknesses(1,2),...
							'actualCoverslip',	thicknesses(2,2),...
							'actualImmersion',	thicknesses(3,2)); 

%Convert to cells
strehlRatio = num2cell(strehlRatio(:));
ensquaredEnergy = num2cell(ensquaredEnergy(:));

%Separate out the PSFs
detectorPSF = squeeze(mat2cell(GibsonLanniPSF,size(GibsonLanniPSF,1),size(GibsonLanniPSF,2),expander));
highResolutionPSF = squeeze(mat2cell(highResGibsonLanniPSF,size(highResGibsonLanniPSF,1),size(highResGibsonLanniPSF,2),expander));

results = struct(	'strehlRatio',			strehlRatio,...
					'ensquaredEnergy',		ensquaredEnergy,...
					'detectorPSF',			detectorPSF,...
					'highResolutionPSF',	highResolutionPSF,...
					'isAccurate',			isAccurate,...
					'wavelength',			lambda,...
					'numericalAperture',	NA,...
					'magnification',		magnification,...
					'pixelSize',			pixelSize,...
					'computationalTime',	computationalTime,...
					'rhoInterval',			1/ceil(rhoResolution));

specific = struct(	'strehlRatio',			exactStrehlRatio,...
					'ensquaredEnergy',		exactEnsquaredEnergy,...
					'detectorPSF',			exactGibsonLanniPSF,...
					'highResolutionPSF',	exactHighResGibsonLanniPSF,...
					'isAccurate',			isExactAccurate,...
					'wavelength',			lambda,...
					'numericalAperture',	NA,...
					'magnification',		magnification,...
					'pixelSize',			pixelSize,...
					'computationalTime',	computationalTime,...
					'rhoInterval',			1/ceil(rhoResolution));

specific(1).refractiveIndices = refractiveIndices;
specific(1).layerThicknesses = specificThicknesses;

				
%Nest the structure appropriately. 
for j=1:nResults
	results(j).refractiveIndices = refractiveIndices;
	results(j).layerThicknesses = layerThicknesses(j);
end
				
%Record
setappdata(handles.Sandia_GibsonLanni_GUI,'Results',results);
setappdata(handles.Sandia_GibsonLanni_GUI,'specificResults',specific);
set(handles.pushExport,'Enable','On')


function pushExport_Callback(hObject, eventdata, handles)

results = getappdata(handles.Sandia_GibsonLanni_GUI,'Results');
specificResults = getappdata(handles.Sandia_GibsonLanni_GUI,'specificResults');
assignin('base','Sandia_Strehl_Scan_Thickness_Results',results);
assignin('base','Sandia_Strehl_Specific_Condition_Results',specificResults);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Functions called above. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function setParameters(handles,lambda,NA,magnification,pixelSize,indices,thicknesses)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract the individual thicknesses and indices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ts = thicknesses(1,1);
TsPrime = thicknesses(1,2);
Tg = thicknesses(2,1);
TgPrime = thicknesses(2,2);
Ti = thicknesses(3,1);
TiPrime = thicknesses(3,2);

Ns = indices(1,1);
NsPrime = indices(1,2);
Ng = indices(2,1);
NgPrime = indices(2,2);
Ni = indices(3,1);
NiPrime = indices(3,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Record the default values. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Set the default microscope parameters. 
set(handles.editWavelength,'String',num2str(lambda))
set(handles.editNA,'String',num2str(NA))
set(handles.editMagnification,'String',num2str(magnification))
set(handles.editPixel,'String',num2str(pixelSize))

%Set the default design indices
if isnan(Ns)
	set(handles.editNs,'String','N/A')
else
	set(handles.editNs,'String',num2str(Ns))
end
set(handles.editNg,'String',num2str(Ng))
set(handles.editNi,'String',num2str(Ni))

%Set the default design thicknesses
set(handles.editTs,'String',num2str(Ts))
set(handles.editTg,'String',num2str(Tg))
set(handles.editTi,'String',num2str(Ti))

%Set the default actual indices
set(handles.editNsPrime,'String',num2str(NsPrime))
set(handles.editNgPrime,'String',num2str(NgPrime))
set(handles.editNiPrime,'String',num2str(NiPrime))

%Set the default actual thicknesses
set(handles.editTsPrime,'String',num2str(TsPrime))
set(handles.editTgPrime,'String',num2str(TgPrime))
set(handles.editTiPrime,'String',num2str(TiPrime))


function [lambda,NA,magnification,pixelSize,indices,thicknesses] = determineCurrentParameters(handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract all the variables. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Get the current microscope parameters. 
lambda = str2double(get(handles.editWavelength,'String'));
NA = str2double(get(handles.editNA,'String'));
magnification = str2double(get(handles.editMagnification,'String'));
pixelSize = str2double(get(handles.editPixel,'String'));

%Get the current design indices
Ng = str2double(get(handles.editNg,'String'));
Ni = str2double(get(handles.editNi,'String'));
% Depends upon Ni
Ns = Ni; 

%Get the current design thicknesses
Ts = 0;	%Always 0
Tg = str2double(get(handles.editTg,'String'));
Ti = str2double(get(handles.editTi,'String'));

%Get the current actual indices
NsPrime = str2double(get(handles.editNsPrime,'String'));
NgPrime = str2double(get(handles.editNgPrime,'String'));
NiPrime = str2double(get(handles.editNiPrime,'String'));

%Set the default actual thicknesses
TsPrime = str2double(get(handles.editTsPrime,'String'));
TgPrime = str2double(get(handles.editTgPrime,'String'));
TiPrime = str2double(get(handles.editTiPrime,'String'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Combine the thicknesses and indices into single variables. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

thicknesses = [[Ts TsPrime]; [Tg TgPrime]; [Ti TiPrime]];
indices = [[Ns NsPrime]; [Ng NgPrime]; [Ni NiPrime]];


function optimumImmersion = exploreOptimumFocus(indices,currentThicknesses,lambda,NA,magnification,maxImmersion,rhoResolution,bestGuess)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Speed things up by using an initial guess, often works. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~isnan(bestGuess)
	%We have an estimate of the optimum immersion oil thickness. Try this
	%as an estimate, using a fine scale (1 nm accuracy)
	guessWindow = .05;
	immersionRange = max((bestGuess-guessWindow),0):.001:(bestGuess+guessWindow);
	strehlRatio = gibsonLanni(indices,currentThicknesses,lambda,NA,magnification,0,rhoResolution,immersionRange);
	[~,loc] = max(strehlRatio);
	
	if loc~=1 || loc~=numel(immersionRange)
		optimumImmersion = immersionRange(loc);
		return
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The initial guess failed. Scan all possibilities. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Set the initial immersion range, scanning all possible thicknesses at the
%specified resolution
bounds = [0 maxImmersion];
resolution = 10; 

while resolution>=.001
	immersionRange = bounds(1):resolution:bounds(2);
	
	%Determine the Strehl ratio for this range at the specified resolution.
	strehlRatio = gibsonLanni(indices,currentThicknesses,lambda,NA,magnification,0,rhoResolution,immersionRange);
	
	%Determine the best guess for the immersion oil thickness. 
	[~,loc] = max(strehlRatio);
	bestGuess = immersionRange(loc);
	
	%Determine new bounds, allowing two resolution increments above and
	%below the current best guess. 
	bounds = [max(bestGuess-2*resolution,0) bestGuess+2*resolution];

	%Adjust the resolution to a finer resolution. 
	resolution = resolution/10;
end

optimumImmersion = bestGuess; 
